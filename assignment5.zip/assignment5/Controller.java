/*Julio Morales
 * 010933308
 * 09/30/2022
 * 
 * controller.java contains the keyboard and mouse methods 
 * in order to move up, down, left, or right and the mouse clicks
 */
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;

class Controller implements ActionListener, MouseListener, KeyListener
{
	View view;
	Model model;
	Pipe pipe;

	boolean keyLeft;
	boolean keyRight;
	boolean keyUp;
	boolean keyDown;
	boolean q;
	boolean esc;
	boolean editing = false;
	boolean keySpace;
	boolean ctrl;

	boolean f = false;

	boolean addGoomba = false;
	boolean addPipe = false;

	//constructor
	Controller(Model m)
	{
		model = m;
	}

	public void actionPerformed(ActionEvent e)
	{
	}


	//view setter
	void setView(View v){
		view = v;
	}


	//mouse accions methods
	public void mousePressed(MouseEvent e)
	{
		if(addGoomba == true && addPipe == false){
            model.addGoomba(e.getX() + View.scrollPosition, e.getY());
			
		}
		else if(addPipe == true && addGoomba == false){
	
			model.addPipe(e.getX() + View.scrollPosition, e.getY());
					
		}

		
		
	}

	public void mouseReleased(MouseEvent e) {    }
	public void mouseEntered(MouseEvent e) {    }
	public void mouseExited(MouseEvent e) {    }
	public void mouseClicked(MouseEvent e) {
		
	}


	//key acction methods
	public void keyPressed(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_RIGHT: keyRight = true; break;
			case KeyEvent.VK_LEFT: keyLeft = true; break;
			case KeyEvent.VK_UP: keyUp = true; break;
			case KeyEvent.VK_DOWN: keyDown = true; break;
			case KeyEvent.VK_Q: q = true; break;
			case KeyEvent.VK_ESCAPE: esc = true; break;
			case KeyEvent.VK_SPACE: keySpace = true; break;
			case KeyEvent.VK_CONTROL: ctrl = true; break;
			case KeyEvent.VK_F: f = true; break;
		}

        if(ctrl == true){
			model.addFireball(model.mario.Xval , model.mario.Yval );
			
		}
	}

	public void keyReleased(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_RIGHT: keyRight = false; break;
			case KeyEvent.VK_LEFT: keyLeft = false; break;
			case KeyEvent.VK_UP: keyUp = false; break;
			case KeyEvent.VK_DOWN: keyDown = false; break;
			case KeyEvent.VK_SPACE: keySpace = false; break;
			case KeyEvent.VK_CONTROL: ctrl = false; break;
			case KeyEvent.VK_F: f = false; break;
		}
		
		char c = Character.toLowerCase(e.getKeyChar());
		if(c == 'q' || c == KeyEvent.VK_ESCAPE){
			System.exit(0);
		}
		if(c == 's'){
			Json saveOb = model.marshal();
			saveOb.save("map.json");
		}
		if(c == 'f'){
			//fireball
			
		}


		
		if((c == 'g' && addGoomba == false) || (c == 'p' && addPipe == false))//enable editing
		{
			
			if(c == 'g'){
				addGoomba = true; 
				System.out.println("addGoomba mode on");
			}
			
	
			if(c == 'p'){
				addPipe = true;
				System.out.println("adding pipes mode on");
			}
			
		}
		else if((c == 'g' && addGoomba == true) || (c == 'p' && addPipe == true))//enable editing
		{
			addGoomba = false;
			addPipe = false;
			System.out.println("edit mode off");
		}
		
	}

	public void keyTyped(KeyEvent e)
	{
	}

	void update()
	{
		// model.goomba.setPrevPosGoomba();
		model.mario.setPrevPos();

		if(keyRight){
			// view.scrollPosition += 10;
			for(int i=0; i < model.sprites.size(); i++){
				if(model.sprites.get(i).isMario()){
					model.sprites.get(i).Xval += 10; 
					model.mario.changeImageState();
					model.mario.rightFacing =true;

				}
			}

		} 
		if(keyLeft) {
			for(int i=0; i < model.sprites.size(); i++){
				if(model.sprites.get(i).isMario()){
					model.sprites.get(i).Xval -= 10; 
					model.mario.changeImageState();
					model.mario.rightFacing = false;
				}
			}
		}
	
		if(keySpace && model.mario.inAir < 5 ){
			//mario jump 
			model.mario.vertVelocity -= 10;
		} 	

		
	}

}