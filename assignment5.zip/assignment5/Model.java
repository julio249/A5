/*Julio Morales
 *ID 010933308
 * 09/30/2022
 * 
 * model.java indicates the state of the game/world and draws the sprites
 */
import java.util.ArrayList; // import the ArrayList class
// import java.util.Iterator;





class Model
{
	int speed = 4;
	
	ArrayList<Sprite> sprites;
	Mario mario;
	
	//constructor to create  sprites and mario
	Model()
	{
		mario = new Mario(500,500);
		// goomba = new Goomba(900,550);

		sprites = new ArrayList<Sprite>();
		sprites.add((Sprite)mario);

	}
	
	
	//unmarshaling constructor
	void unmarshal(Json ob){
		sprites = new ArrayList<Sprite>();
		sprites.add(mario);

		Json tmpList = ob.get("pipes");
		for(int i=0; i < tmpList.size(); i++){
			sprites.add(new Pipe(tmpList.get(i)));
		}
		Json tmpListgoomba = ob.get("goomba");
		for(int i=0; i < tmpListgoomba.size(); i++){
			sprites.add(new Goomba(tmpListgoomba.get(i)));
		}
	}

	//marshal method that uses marshal method from Pipe class
	Json marshal(){
		Json ob = Json.newObject();
		Json tmpListPipes = Json.newList();
		ob.add("pipes", tmpListPipes);

		Json tmpListMario = Json.newList();
		ob.add("Mario", tmpListMario);

		Json tmpListGoomba = Json.newList();
		ob.add("goomba", tmpListGoomba);

		for(int i=0; i < sprites.size(); i++){
			if(sprites.get(i).isPipe()){
				System.out.println("calling pipe marshaller");
				tmpListPipes.add(sprites.get(i).marshaller());
			}
			if(sprites.get(i).isGoomba()){
				System.out.println("goomba marshalled");
				tmpListGoomba.add(sprites.get(i).marshaller());
			}
			if(sprites.get(i).isMario()){
				System.out.println("calling mario marshaller");
				tmpListMario.add(sprites.get(i).marshaller());
			}
		}

		return ob;
	}
	
	
	public void update()
	{
		boolean pipecolision = false;
		

		for(int i = 0; i < sprites.size(); i++)
		{
			sprites.get(i).update();
		}

		for(int i=0; i < sprites.size(); i++){
	
			if(sprites.get(i).isMario())//INTERACTION MARIO->PIPE
			{
				for(int j=0; j < sprites.size(); j++){
					if(sprites.get(j).isPipe()){
						if(isThereACollision((Mario)mario, sprites.get(j)))
						{
								mario.getOutOfPipe((Pipe)sprites.get(j));
							
							
						}

					}

				}
				
				
			}
			
			
			if (sprites.get(i).isGoomba()){//GOOMBA
				
				for (int j = 0; j < sprites.size(); j++)
				{
					if ( sprites.get(j).isPipe())
					{
						pipecolision = isThereACollision(sprites.get(i) , sprites.get(j));
					}
						if (pipecolision) 
						{
							
							((Goomba)sprites.get(i)).getOutOfPipe((Pipe)sprites.get(j));
							
						}
					
					pipecolision = false;
				}


						

				if( ( (Goomba)sprites.get(i)).setFire)
				{
					((Goomba)sprites.get(i)).timeOnFire--;
				}
				if( ( ((Goomba)sprites.get(i)).setFire) && ((Goomba)sprites.get(i)).timeOnFire == 0)
				{
					sprites.remove(i);
					break;
				}
					
			}
					
			if(sprites.get(i).isFireball())
			{
				
				for(int j=0; j < sprites.size(); j++)
				{
					//j is the goomba sprite
					if(sprites.get(j).isGoomba())
					{
					
						if(isThereACollision(sprites.get(i), sprites.get(j)))
						{
							((Goomba)sprites.get(j)).setFire = true;
							sprites.remove(sprites.get(i));
							break;
						
						}
						pipecolision = false;
					}
					
					
				}
					
				
			}

		}
			
		
	}	
	
	//verifies if the click is on an existing pipe of not in order to add or remove			
	public void addPipe(int x, int y){
			
			Sprite t = new Pipe(x, y);
			boolean pipeExists = false;//bool variable to keep track when a pipe is clicked
			
			for(int i=0; i < sprites.size(); i++){
				if(sprites.get(i).isPipe())
				{
					if(((Pipe) sprites.get(i)).clickOnExistinPipe(x,y))
					{
						sprites.remove(i);
						pipeExists =true;
					}
				}
				
			}
		
			if(!pipeExists){
				sprites.add(t);
			}
		}

		public void addGoomba(int x, int y){
			Sprite g = new Goomba(x, y);
			boolean goombaExists = false;

			for(int i=0; i < sprites.size(); i++){
				
				if(sprites.get(i).isGoomba())
				{
					if(((Goomba) sprites.get(i)).clickOnExistinGoomba(x,y))
					{
						sprites.remove(i);
						goombaExists =true;
					}
				}
			}
			if(!goombaExists){
				
				sprites.add(g);
			}
		}

	public void addFireball(int x, int y){
		Sprite fireball = new Fireball(x, y);


		sprites.add(fireball);
	}

	//check if collision happens and return true when does
	public boolean isThereACollision(Sprite spriteA, Sprite sprite){
		
			
				if(spriteA.Xval + spriteA.w < sprite.Xval ){
					//mario not colliding from left to right
					
					return false;
				}

				if(spriteA.Xval > sprite.Xval + sprite.w){
					//mario not colliding from right to left
					return false;
				}

				if(spriteA.Yval + spriteA.h < sprite.Yval){
					//colliding from top to bottom
					return false;
				} // assumes bigger is downward
				if(spriteA.Yval > sprite.Yval + sprite.h){
					return false;
				} // assumes bigger is downward
				// System.out.println("mario coliding");
			
			return true;
	}

	public boolean isThereACollisionGoomba(Sprite Asprite, Sprite sprite){
		
			if (Asprite.Yval + Asprite.h < sprite.Yval)
			{
				return false;
			} 
			if (Asprite.Xval + Asprite.w < sprite.Xval) 
			{			

			return false;  
			}
			if (Asprite.Yval > sprite.Yval + sprite.h) 
			{			
				
				return false;
			}
			if (Asprite.Xval < sprite.Xval +  sprite.w) 
			{			

				return false;
			}
			return true;
	}
		

	
}
