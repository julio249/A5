/*
 * Julio Morales
 * ID 010933308
 */

import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class Goomba extends Sprite{
    static BufferedImage G;
    static BufferedImage goombaOnFire;
    double vertVelocity = 1.2;
    int inAir = 0;

    boolean setFire = false;
    int bounce = 0;
    int timeOnFire = 10;

    private boolean goingRight = false;
    private boolean goingLeft = true;
    boolean colision = false;

    int prevX;
    int prevY;

    
    public Goomba(int x, int y){
        this.Xval = x;
        this.Yval = y;
        this.h = 45;
        this.w = 37;

        if(G == null){
            G = View.loadImage("goomba.png");
        }
    }


    public Goomba(Json ob) {
        Xval = (int)ob.getLong("Xval");
        Yval = ((int)ob.getLong("Yval"));
        h = 45;
        w = 37;
        if(G == null){
            G = View.loadImage("goomba.png");
        }
        if (goombaOnFire == null)
		{
			goombaOnFire = View.loadImage("goomba_fire.png");	
		}
    }

    public void goombaUpdate()
	{
		
		if (goombaOnFire == null)
		{
			goombaOnFire = View.loadImage("goomba_fire.png");	
		}
	}

    public boolean clickOnExistinGoomba(int clickX, int clickY){
        if(clickX >= Xval && clickX <= Xval + w && clickY >= Yval && clickY <= Yval + h){
            return true;
        }
        else{
            return false;
        }
    }

    public void getOutOfPipe(Sprite p){
        
        //goomba  left collision
        if(p.isPipe() == true){
            

            if(Xval + w >= p.Xval && prevX + w <= p.Xval){
                
                Xval = prevX;
                goingLeft = true;
                goingRight = false;
            }
            //goomba coming from right collision
            if(Xval + w >= p.Xval && prevX - w>= p.Xval ){
                Xval = prevX;
                goingLeft = false;
                goingRight = true;
            }
    
            //collision from top to bottom
            if(Yval + h >= p.Yval && prevY  <= p.Yval){
                Yval = p.Yval - h;
                vertVelocity = 0.0;
                inAir = 0;
            }
            //goomba colliding from bottom to top
            if(Yval <= p.Yval + p.h && prevY >= p.Yval + p.h ){
                Yval = p.Yval + p.h;
                vertVelocity = 0.0;
                inAir = 0;
            }


        }
        
    }


    

    public void setPrevPosGoomba(){
        prevX = Xval;
        prevY = Yval;
        
    }
    


    public void stopGoomba (Sprite f)
	{
		int goombaBottom = Yval + h;
		int fireballBottom	= f.Yval + f.h;

		if (Xval + w >= f.Xval && prevX <= f.Xval )
		{
			Xval = 0;
			Yval = 0;
			
		}

		//Right Collision Fixing
		if (Xval + w >= f.Xval && prevX >= f.Xval + f.w)
		{
			
			Xval = 0;
			Yval = 0; 
			
		}

	
		if ((f.Yval <= goombaBottom) && (fireballBottom>= goombaBottom) && ((prevY + h) <= f.Yval)) 
		{
			
			Xval = 0;
			Yval = 0; 
						
		}

		if ((f.Yval <= goombaBottom) && (fireballBottom>= f.Yval + f.h)) 
		{
			
			Xval = 0;
			Yval = 0; 
			
		}


	}






    @Override
    public boolean isGoomba(){
        return true;
    }
    @Override
    public void draw(Graphics g, int scroll) {
        // TODO Auto-generated method stub
        if(setFire){
            g.drawImage(goombaOnFire, Xval - scroll, Yval, null);
        }
        else{
            g.drawImage(G, Xval - scroll, Yval, null);

        }
    }

    @Override
    public void update() {
        // TODO Auto-generated method stub
       setPrevPosGoomba();
        vertVelocity += 3.5;//this is gravity
        Yval  += vertVelocity;
        inAir++;
        if(Yval > 500 ){ ///
            vertVelocity = 0.0;
            Yval = 500; //is on a pipe jumps as if he was in the ground
            inAir = 0;
        }

        if (goingLeft)
            {
                this.Xval -= 4;
                goingRight = false;
            }
             if (goingRight)
            {
                goingLeft = false;
                this.Xval += 4;
            }

    }

    // @Override
    Json marshaller() {
        Json ob = Json.newObject();
        
        ob.add("Xval", Xval);
        ob.add("Yval", Yval);
        ob.add("h", h);
        ob.add("w", w);
        return ob;
    }

    
    @Override 
	public String toString()
	{
        return "goomba (x,y) = (" + Xval + ", " + Yval + ")";
	}
}
