import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Fireball extends Sprite{
    static BufferedImage F;
    double vertVelocity = 3.2;
    double  ySpeed = 0;
    int inAir = 0;

    static boolean isActive = true;

    // Model model; 

    int prevX;
    int prevY;

    
    public Fireball(int x, int y){
        this.Xval = x;
        this.Yval = y;
        this.h = 47;
        this.w = 47;

        isActive = true;

        if(F == null){
            F = View.loadImage("fireball.png");
        }
    }


    public void updateFireballState()
	{
		isActive = !isActive;
	}
	public boolean getFireballState()
	{
		return isActive;
	}



    @Override
    public void draw(Graphics g, int scroll) {
        // TODO Auto-generated method stub
        g.drawImage(F, Xval - scroll, Yval + h, null);
    }

    @Override
    public void update() {
        // TODO Auto-generated method stub
    

        vertVelocity += 3.5;//this is gravity
        Yval  += vertVelocity;
        Xval += 5;
        inAir++;
        if(Yval > 500 ){ 
            vertVelocity -= 50;
            Yval = 500 ; 
            inAir = 0;
        }


    
    }

    @Override
    Json marshaller() {
        // TODO Auto-generated method stub
        return null;
    }
    @Override
    public boolean isFireball() {
        // TODO Auto-generated method stub
        return true;
    }
    
}
