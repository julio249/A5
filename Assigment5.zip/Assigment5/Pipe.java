// import org.w3c.dom.events.MouseEvent;

/*Julio Morales
 *ID 010933308
 * 
 * 
 */

import java.awt.Graphics;
import java.awt.image.BufferedImage;
// import java.awt.Graphics;


 class Pipe extends Sprite{
    


    static BufferedImage P;

    public Pipe(int x, int y){
        this.Xval = x;
        this.Yval = y;
        h = 390;
        w = 55;

        if(P == null){
            P = View.loadImage("pipe.png");
        }
    }

    //unmarsaling constructor: retrieve atributes from json
    public Pipe(Json ob){ 
        Xval = (int)ob.getLong("Xval");
        Yval = ((int)ob.getLong("Yval"));
        h = 400;
        w = 55;
        if(P == null){
            P = View.loadImage("pipe.png");
        }
    }
    
    // //marshaling: saves necessary atributes to Json
    Json marshaller(){
        Json ob = Json.newObject();
        
        ob.add("Xval", Xval);
        ob.add("Yval", Yval);
        ob.add("h", h);
        ob.add("w", w);
        return ob;
    }
    
    //make sure click is within bounds of image:
    public boolean clickOnExistinPipe(int clickX, int clickY){
        if(clickX >= Xval && clickX <= Xval + w && clickY >= Yval && clickY <= Yval + h){
            return true;
        }
        else{
            return false;
        }
    }
    
    @Override
    public boolean isPipe()
    {
        return true;
    }
    @Override
    public void update() {
        // TODO Auto-generated method stub
        
    }

    @Override 
	public String toString()
	{
        return "pipe (x,y) = (" + Xval + ", " + Yval + ")";
	}

    
    @Override
    public void draw(Graphics g, int scroll) {
        // TODO Auto-generated method stub
        g.drawImage(P, Xval - scroll, Yval, null);//spawms sprites where clicked
        
       
    }
    }