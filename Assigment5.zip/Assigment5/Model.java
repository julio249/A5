/*Julio Morales
 *ID 010933308
 * 09/30/2022
 * 
 * model.java indicates the state of the game/world and draws the sprites
 */
import java.util.ArrayList; // import the ArrayList class
// import java.util.Iterator;





class Model
{
	int speed = 4;
	// int prevX;
	// int prevY;
	// ArrayList<Pipe> pipes;
	ArrayList<Sprite> sprites;
	Mario mario;
	// Goomba goomba;
	// Fireball fireball;
	
	//constructor to create  sprites and mario
	Model()
	{
		mario = new Mario(500,500);
		// goomba = new Goomba(900,550);

		sprites = new ArrayList<Sprite>();
		sprites.add((Sprite)mario);

	
		// sprites.add((Sprite) goomba);
	}
	
	
	//unmarshaling constructor
	void unmarshal(Json ob){
		sprites = new ArrayList<Sprite>();
		sprites.add(mario);
		// sprites.add(goomba);

		Json tmpList = ob.get("pipes");
		for(int i=0; i < tmpList.size(); i++){
			sprites.add(new Pipe(tmpList.get(i)));
		}
		Json tmpListgoomba = ob.get("goomba");
		for(int i=0; i < tmpListgoomba.size(); i++){
			System.out.println("goomba unmarshaled");
			sprites.add(new Goomba(tmpListgoomba.get(i)));
		}
	}

	//marshal method that uses marshal method from Pipe class
	Json marshal(){
		Json ob = Json.newObject();
		Json tmpListPipes = Json.newList();
		ob.add("pipes", tmpListPipes);

		Json tmpListMario = Json.newList();
		ob.add("Mario", tmpListMario);

		Json tmpListGoomba = Json.newList();
		ob.add("goomba", tmpListGoomba);

		for(int i=0; i < sprites.size(); i++){
			if(sprites.get(i).isPipe()){
				System.out.println("calling pipe marshaller");
				tmpListPipes.add(sprites.get(i).marshaller());
			}
			if(sprites.get(i).isGoomba()){
				System.out.println("goomba marshalled");
				tmpListGoomba.add(sprites.get(i).marshaller());
			}
			if(sprites.get(i).isMario()){
				System.out.println("calling mario marshaller");
				tmpListMario.add(sprites.get(i).marshaller());
			}
		}

		return ob;
	}
	
	
	public void update()
	{
		boolean pipecolision = false;
		boolean checkColision = false;

		for(int i=0; i < sprites.size(); i++){
			sprites.get(i).update(); 
			// System.out.println("GOOMBA is: " + sprites.get(i).isGoomba());
			if(!sprites.get(i).isMario())//INTERACTION MARIO->PIPE
			{
				
				if(isThereACollision(mario, sprites.get(i)))
				{
					if(sprites.get(i).isPipe()){
						mario.getOutOfPipe((Pipe)sprites.get(i));
					}
					
				}
				
				
			}

			if (sprites.get(i).isGoomba()){//GOOMBA

				for (int j = 0; j < sprites.size(); j++)
				{
					if ( sprites.get(j).isPipe())
					{
						pipecolision = isThereACollision((Goomba) sprites.get(i) , sprites.get(j));
						if (pipecolision) 
						{
							
							((Goomba)sprites.get(i)).getOutOfPipe(sprites.get(j));
							
						}
					}
					
					pipecolision = false;
						
					if(sprites.get(j).isFireball()){
						checkColision = isThereACollision((Goomba) sprites.get(i) ,(Fireball) sprites.get(j)) ;
						// System.out.println(checkColision);
						
						if(checkColision){
							 System.out.println("GOOMBA ON FIREE");
	 
						 }
					}
						// boolean checkState = ((Fireball) sprites.get(j)).getFireballState();
					checkColision = false;
				}
				// for(int l=0; l< sprites.size(); l++){
				// 	if(sprites.get(l).isFireball()){
				// 		// System.out.println(isThereACollisionGoomba((Goomba) sprites.get(i) , (Fireball)sprites.get(l)));
				// 		if(isThereACollision((Goomba) sprites.get(i) , (Fireball)sprites.get(l))){
				// 			System.out.println("GOOMBA ON FIREE");
				// 		}
				// 	}
				// }


			}

/////////////////////////////////////////////////////////////////////////

			
		}
	}	
	
	//verifies if the click is on an existing pipe of not in order to add or remove			
	public void addPipe(int x, int y){
			
			Sprite t = new Pipe(x, y);
			boolean pipeExists = false;//bool variable to keep track when a pipe is clicked
			
			// Iterator<Sprite> it = sprites.iterator();


			for(int i=0; i < sprites.size(); i++){
				// System.out.println("is pipe? " + sprites.get(i).isPipe());
				if(sprites.get(i).isPipe())
				{
					if(((Pipe) sprites.get(i)).clickOnExistinPipe(x,y))
					{
						sprites.remove(i);
						pipeExists =true;
						// System.out.println("clicked on existing pipe");
					}
				}
				
			}
		//iterator implementation///
			// while(it.hasNext()){
			// 	if(it.next().isPipe() == true){
			// 		if(( (Pipe) it.next()).clickOnExistinPipe(x, y)) //isPipe?
			// 		{
			// 			it.remove();
			// 			pipeExists = true;
			// 		}

			// 	}
			// }
				
			if(!pipeExists){
				// System.out.println("SPRITE ADDED");
				sprites.add(t);
			}
		}

		public void addGoomba(int x, int y){
			Sprite g = new Goomba(x, y);
			boolean goombaExists = false;

			for(int i=0; i < sprites.size(); i++){
				
				if(sprites.get(i).isGoomba())
				{
					if(((Goomba) sprites.get(i)).clickOnExistinGoomba(x,y))
					{
						sprites.remove(i);
						goombaExists =true;
					}
				}
			}
			if(!goombaExists){
				// System.out.println("SPRITE ADDED");
				sprites.add(g);
			}
		}

	public void addFireball(int x, int y){
		Sprite fireball = new Fireball(x, y);


		sprites.add(fireball);
	}

	//check if collision happens and return true when does
	public boolean isThereACollision(Sprite mario, Sprite sprite){
		// System.out.println(mario.Xval + " " + sprite.Xval);
			
				if(mario.Xval + mario.w < sprite.Xval ){
					//mario not colliding from left to right
					
					return false;
				}

				if(mario.Xval > sprite.Xval + sprite.w){
					//mario not colliding from right to left
					return false;
				}

				if(mario.Yval + mario.h < sprite.Yval){
					//colliding from top to bottom
					return false;
				} // assumes bigger is downward
				if(mario.Yval > sprite.Yval + sprite.h){
					return false;
				} // assumes bigger is downward
				// System.out.println("mario coliding");
			
			return true;
	}

	public boolean isThereACollisionGoomba(Sprite goomba, Sprite sprite){
		// System.out.println(mario.Xval + " " + sprite.Xval);
			
			// 	if(goomba.Xval + goomba.w < sprite.Xval ){
			// 		//mario not colliding from left to right
					
			// 		return false;
			// 	}
				
			// 	if(goomba.Xval > sprite.Xval + sprite.w){
			// 		//mario not colliding from right to left
			// 		return false;
			// 	}
				
			// 	if(goomba.Yval + goomba.h > sprite.Yval){
			// 		//colliding from top to bottom
			// 		return false;
			// 	} // assumes bigger is downward
			// 	if(goomba.Yval > sprite.Yval + 2*sprite.h){
			// 		// System.out.println();
			// 		return false;
			// 	} // assumes bigger is downward
			// 	System.out.println("GOOMBA coliding");
			
			// return true;
			
			if (goomba.Yval + goomba.h < sprite.Yval)
			{
				return false;
			} 
			if (goomba.Xval + goomba.w < sprite.Xval) 
			{			
				System.out.println("COLLISIOOOON");

			return false;  
			}
			if (goomba.Yval > sprite.Yval + sprite.h) 
			{			
				
				return false;
			}
			if (goomba.Xval < sprite.Xval +  sprite.w) 
			{			

				return false;
			}
			return true;
	}
		

	
}
